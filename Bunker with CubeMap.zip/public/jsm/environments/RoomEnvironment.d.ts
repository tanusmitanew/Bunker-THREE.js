import { Scene } from '../../../src/Three';

export class RoomEnvironment extends Scene {

	constructor();

}
